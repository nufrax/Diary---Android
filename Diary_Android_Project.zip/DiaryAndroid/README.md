# Diary Android wrapper (source project)

This is an Android Studio project for a lightweight Android app wrapper around the existing Diary PHP site. It keeps PHP/MySQL and user data on the existing HTTPS server; it does not duplicate or migrate the database.

## Build APK
1. Install Android Studio on a computer, or use a trusted cloud Android build environment.
2. Open this `DiaryAndroid` folder as an existing project.
3. Allow Gradle to sync (Android Gradle Plugin 8.7.3, compile SDK 35).
4. Use **Build > Build APK(s)**.
5. Test the APK on your own device before sharing it.

This ZIP contains source code, **not a compiled APK**. Building needs Android SDK/Gradle and internet access for dependencies.

## Notes
- App URL: `https://genora.uz/Diary/login.php`
- Requires internet and a Diary account.
- Upload file chooser and Android back navigation are supported.
- Only links on `genora.uz` stay inside the app; external links open in the browser.
- Before public release, add a proper launcher icon, privacy policy, verify Google sign-in in WebView, and test file upload/session behavior on actual devices.
